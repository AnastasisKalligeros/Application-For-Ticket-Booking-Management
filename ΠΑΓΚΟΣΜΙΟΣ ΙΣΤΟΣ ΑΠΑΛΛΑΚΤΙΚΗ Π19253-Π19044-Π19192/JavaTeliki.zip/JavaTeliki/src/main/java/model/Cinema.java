package model;


public class Cinema {
	
	private String cinemaID;
	private String name;
	private String seats;
	private Boolean D3;
	
	public Cinema() {
		
		
	}
	
	public String getCinemaID() {
		return cinemaID;
	}



	public void setCinemaID(String cinemaID) {
		this.cinemaID = cinemaID;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getSeats() {
		return seats;
	}



	public void setSeats(String seats) {
		this.seats = seats;
	}



	public Boolean getD3() {
		return D3;
	}



	public void setD3(Boolean d3) {
		D3 = d3;
	}



	

		
}