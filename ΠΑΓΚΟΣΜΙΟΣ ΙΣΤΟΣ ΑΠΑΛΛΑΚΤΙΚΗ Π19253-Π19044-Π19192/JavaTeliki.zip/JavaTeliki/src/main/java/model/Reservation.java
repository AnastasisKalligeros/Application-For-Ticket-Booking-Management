package model;


public class Reservation {
	

	private String NumberOfSeats;
	private String name;
    private String CinemasID;
	private String CustomersID;
	private String ID;
	public String getNumberOfSeats() {
		return NumberOfSeats;
	}
	public void setNumberOfSeats(String numberOfSeats) {
		NumberOfSeats = numberOfSeats;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	
	public String getCinemasID() {
		return CinemasID;
	}
	public void setCinemasID(String cinemasID) {
		CinemasID = cinemasID;
	}
	public String getCustomersID() {
		return CustomersID;
	}
	public void setCustomersID(String customersID) {
		CustomersID = customersID;
	}
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public Reservation() {
		
		
	}
	

}
	


	
	
		
